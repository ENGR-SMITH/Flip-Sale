---
name: Playwright Chromium runtime
description: Runtime libraries needed by Playwright's downloaded Chromium headless shell in this workspace.
---

If Playwright's Chromium process exits with a missing `libgbm.so.1`, install the Nix `libgbm` system dependency. Installing the broader Chromium libraries and `mesa` alone did not provide it.

**Why:** The headless shell would not launch in this NixOS environment without `libgbm.so.1`.

**How to apply:** When a Playwright browser launch fails before tests start, inspect the browser binary with `ldd` and install the missing Nix library instead of repeating the browser download.
